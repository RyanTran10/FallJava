package pokemon;

public class James extends Pokemon {

	public James() {
		super("James", 0, 1, "James.png", new Move[] {new Move("Politics", 0, 0, 0), new Move("Politics", 0, 0, 0), new Move("Politics", 0, 0, 0), new Move("Politics", 0, 0, 0)});
	}
	
}
