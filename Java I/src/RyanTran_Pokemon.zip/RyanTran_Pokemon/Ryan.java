package pokemon;

public class Ryan extends Pokemon {

	public Ryan() {
		super("Ryan", 0, 300, "Ryan.PNG", new Move[] {new Move("Slap", 0, 82, 1), new Move("Slap", 0, 81, 1), new Move("Slap", 0, 81, 1), new Move("Slap", 0, 81, 1)});
	}
}
