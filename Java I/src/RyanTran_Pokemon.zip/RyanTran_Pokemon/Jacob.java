package pokemon;

public class Jacob extends Pokemon {

	public Jacob() {
		super("Jacob", 0, 1, "jacob.png", new Move[] {new Move("Politics", 0, 0, 0), new Move("Politics", 0, 0, 0), new Move("Politics", 0, 0, 0), new Move("Politics", 0, 0, 0)});
	}
	
}
